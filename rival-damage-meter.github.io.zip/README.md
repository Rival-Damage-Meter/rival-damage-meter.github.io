# Rival Damage Meter website

Static website and interactive browser trial for Rival Damage and Threat Meter.

Target address: https://rival-damage-meter.github.io/

## Publish with GitHub Pages

1. Use the free GitHub organization `Rival-Damage-Meter`.
2. Create a public repository named `rival-damage-meter.github.io` in that organization.
3. Push these website files to its `main` branch.
4. In repository Settings → Pages, choose GitHub Actions as the build source.
5. Run the Publish Rival website workflow. Later pushes to `main` publish updates automatically.

The matching organization name is required for the target address. All asset paths are relative, so the same files also work as a project site if the repository owner changes.

## Local preview

Run `node preview.mjs`, then open http://127.0.0.1:4173/.
After editing CSS or JavaScript, run `node stamp-assets.mjs` to update the referenced file versions.

## Contents

`dist/` contains the website and public demo assets. `.github/workflows/pages.yml` publishes it without a framework, server, database, or paid hosting dependency. No addon Lua source, account data, combat-log archives, credentials, or prior private site history are included.

Browser encounters use fictional data. Imported logs are read locally in the browser. Asset attribution is in `dist/assets/`; World of Warcraft assets remain the property of Blizzard Entertainment. Rival is a fan-made addon and is not affiliated with Blizzard Entertainment.
