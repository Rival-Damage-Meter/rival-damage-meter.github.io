import { readFileSync, writeFileSync, copyFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
const file='dist/index.html';
const before=readFileSync(file,'utf8');
const after=before.replace(/(src|href)="([^"?]+\.(?:css|js))(?:\?[^\"]*)?"/g,(match,attribute,asset)=>{
  if(/^https?:/.test(asset))return match;
  const canonical=asset.replace(/\.[a-f0-9]{12}(?=\.(?:css|js)$)/,'');
  const version=createHash('sha256').update(readFileSync(resolve('dist',canonical))).digest('hex').slice(0,12);
  const fingerprint=canonical.replace(/\.(css|js)$/,`.${version}.$1`);
  copyFileSync(resolve('dist',canonical),resolve('dist',fingerprint));
  return `${attribute}="${fingerprint}"`;
});
if(before!==after)writeFileSync(file,after);
console.log('Styles and scripts use content versions so browsers load the updated UI.');
